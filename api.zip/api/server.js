// backend/server.js
import express from "express";
import cors from "cors";
import "dotenv/config";
import connectDB from "./config/mongodb.js";
import connectCloudinary from "./config/cloudinary.js";
import userRouter from "./routes/userRoute.js";
import productRouter from "./routes/productRoute.js";
import cartRouter from "./routes/cartRoute.js";
import orderRouter from "./routes/orderRoute.js";

// App configuration
const app = express();
connectDB();
connectCloudinary();

// Middleware
app.use(express.json());
app.use(cors());

// API Endpoints
app.use(["/api/user", "/user"], userRouter);
app.use(["/api/product", "/product"], productRouter);
app.use(["/api/cart", "/cart"], cartRouter);
app.use(["/api/order", "/order"], orderRouter);

// Test endpoint
app.get("/", (req, res) => {
  res.send("API working");
});

// Do NOT call app.listen() here
export default app;
